T = 0.01;           % 采样周期
fs = 1/T;           % 采样频率
ws = 2 * pi / T;    % ws
N = 1024;           % 采样点数目
M = 2048;           % FIR 采样点数目 
n = 0:1:N-1;
t = n * T *0.1;
t1 = n * T ;        % 冲击采样
x=0.5*sin(2*pi*t)+2*sin(2*pi*10*t); % 源信号

xp=0.5*sin(2*pi*t1)+2*sin(2*pi*10*t1);  % 冲激采样 x[n]

xw = fft(x,N);

xw = fftshift(xw);

xw = abs(xw);                     % 源信号频谱



xpw = fft(xp,N);

xpw = fftshift(xpw);

xpw = abs(xpw);                           % 冲激采样频谱

f = n * fs/N;                      
f1 = n * fs/N - fs/2;

% 零阶保持频谱
H0w = Hw(f1,T);

x0w = xpw .* H0w;

% 重建H'(jw)

Hjw_new = Hrw(f1,T);

% 联合H(jw)

Hjw = H0w .* Hjw_new;

subplot(4,2,1);plot(t,x);ylabel('原信号');axis([0 0.5 -3 3]);grid on;
subplot(4,2,2);plot(f1,xw);ylabel('原信号频谱');axis([-40 40 0 800]);grid on;
subplot(4,2,3);stem(t1,xp);ylabel('原信号冲激采样');axis([0 0.5 -3 3]);grid on;
subplot(4,2,4);plot(f1,xpw);ylabel('原信号冲激采样频谱');axis([-40 40 0 800]);grid on;
subplot(4,2,5);plot(f1,H0w);ylabel('零阶保持响应频谱');axis([-40 40 0 800]);grid on;
subplot(4,2,6);plot(f1,x0w);ylabel('零阶保持频谱');axis([-40 40 0 800]);grid on;
subplot(4,2,7);plot(f1,Hjw_new);ylabel('重建Hjw');axis([-40 40 0 800]);grid on;
subplot(4,2,8);plot(f1,Hjw);ylabel('联合Hjw');axis([-40 40 0 800]);grid on;

