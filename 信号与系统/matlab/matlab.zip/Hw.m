function H = Hw(w,T)
    %零阶保持滤波器H0(jw)
    H = T .* sin(w.*T./2) ./(w.*T./2);
end