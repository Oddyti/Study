%% 初始化棋盘
define_coef;
global BOARD_LEN;
global win;
board = zeros(BOARD_LEN);

while 1
    human_x = input('玩家请输入下一步棋子的横坐标：x = ');
    human_y = input('玩家请输入下一步棋子的纵坐标：y = ');
    
    if board(human_x, human_y) ~= 0
        disp('当前位置已经有棋子啦！请重新落子到空位上！')
        human_x = input('玩家请输入下一步棋子的横坐标：x = ');
        human_y = input('玩家请输入下一步棋子的纵坐标：y = ');
    end
    
    board(human_x, human_y) = 1;
    for_show(board)
    win = is_win(board);
    if win == 1
        disp('恭喜玩家获胜！！！')
        break;
    elseif win == 2
        disp('电脑获胜！！！')
        break;
    end
    
    disp('----------------------------稍候，电脑正在计算下一步棋子--------------------')
    tic;
    [pc_score_now, pc_x, pc_y] = find_bestmove(board);
    toc;
    board(pc_x, pc_y) = 2;
    for_show(board)
    
    win = is_win(board);
    if win == 1
        disp('恭喜玩家获胜！！！')
        break;
    elseif win == 2
        disp('电脑获胜！！！')
        break;
    end
    
end